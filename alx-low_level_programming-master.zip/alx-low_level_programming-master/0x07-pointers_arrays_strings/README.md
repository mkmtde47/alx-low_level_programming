This directory is holding tasks for pointers
and arrays, it a continuation like the previous.
