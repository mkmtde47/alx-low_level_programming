This directory has tasks on memory allocation
