This directory contains tasks on linked list
