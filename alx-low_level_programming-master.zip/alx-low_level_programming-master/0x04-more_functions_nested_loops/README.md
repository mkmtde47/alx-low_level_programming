More tasks on functions and nested loops
