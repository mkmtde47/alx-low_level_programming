#include "main.h"

/**
  * mul - Multiplies two numbers
  * @a: First number
  * @b: Second number
  * Return: product
  */
int mul(int a, int b)
{
	int prod;

	prod = a * b;
	return (prod);
}
