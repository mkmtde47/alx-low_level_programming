This directory contains more tasks on
strings, arrays and pointers
