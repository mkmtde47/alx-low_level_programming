This directory contains tasks on more linked lists
