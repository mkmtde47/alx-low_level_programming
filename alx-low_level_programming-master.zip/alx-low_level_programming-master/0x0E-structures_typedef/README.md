This directory contains task on structures aand typedefs
