More tasks on memory allocation
