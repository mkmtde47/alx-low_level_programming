This directory contains tasks on variadic functions
