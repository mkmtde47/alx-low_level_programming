#include "main.h"

int main(void)
{
	int c;

	c = print_argc();
	return (0);
}
