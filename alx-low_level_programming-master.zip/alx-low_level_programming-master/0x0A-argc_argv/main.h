#ifndef MAIN_H
#define MAIN_H

#include <string.h>
#include <stdio.h>

int print_name(int argc, char **argv);
int print_argc(int argc, char **argv);
#endif
