#include "main.h"

/**
  * reset_to_98 - Uses pointer to change value of variable
  * @n: Point to variable
  */
void reset_to_98(int *n)
{
	*n = 98;
}
