This directory contains tasks on pointers, arrays and strings
