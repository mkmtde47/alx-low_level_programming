#include "main.h"

int _atoi(char *s)
{
	*(s) = *(s + 1);
	return (1);
}
