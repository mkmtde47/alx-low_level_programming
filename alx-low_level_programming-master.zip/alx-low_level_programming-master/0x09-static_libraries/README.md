My very first library
