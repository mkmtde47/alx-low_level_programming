#include "main.h"
/**
  * main - Entry point
  * Return: Zero if successful
  */
int main(void)
{
	printf("%s", __FILE__);
	printf("\n");
	return (0);
}
