#ifndef MAIN_H
#define MAIN_H

#define SIZE 1024

#endif
