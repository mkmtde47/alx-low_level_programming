#ifndef MAIN_H
#define MAIN_H

#define ABS(x) ((x) < (0) ? (-1 * x) : (x))
#endif
