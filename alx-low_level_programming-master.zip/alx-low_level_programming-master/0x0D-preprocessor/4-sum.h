#ifndef MAIN_H
#define MAIN_H

#define SUM(x, y) (x + y)
#endif
