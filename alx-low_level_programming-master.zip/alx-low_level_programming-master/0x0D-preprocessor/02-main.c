#include "main.h"

int main(void)
{
	printf("%s", __FILE__);
	printf("\n");
	return (0);
}
