#include <stdio.h>

/**
  * main - Entry point
  *
  * Return: Zero if successful
  */
int main(void)
{
	int base16[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
	char baseabc[] = {'a', 'b', 'c', 'd', 'e', 'f'};
	int i;

	for (i = 0; i < 10 ; i++)
	{
		putchar('0' + base16[i]);
	}
	for (i = 0; i < 6; i++)
	{
		putchar(baseabc[i]);
	}
	putchar('\n');
	return (0);
}
