This program generates a random
number everytime it is run. It then
prints out the nature of the number
positive, negative or simply zero.
